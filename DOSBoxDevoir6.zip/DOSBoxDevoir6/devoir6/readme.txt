Ce kit de d�veloppement fonctions sour DOS (Windows -> invite de commande).

FCEUXD.EXE : �mulateur NES.  Offre des options de d�buggage.

NESASM.EXE : compilateur NES.  Utilisation: nesasm fichier.asm

TLP.EXE : Tile Layer Pro, logiciel d'�dition des tuiles.  Ne devrait pas vous servir, mais peut
vous aider � retrouver des morceaux d'images parmi les tuiles de votre ROM.
Les tuiles se trouvent dans le fichier "smbvrom.nes".

